from flask import Flask, request, render_template
import subprocess

app = Flask(__name__)

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Network Utility</title>
</head>
<body>
    <h2>Ping Diagnostic Tool</h2>

    <form method="POST">
        <input type="text" name="host" placeholder="Enter host" />
        <button type="submit">Run</button>
    </form>

    {% if output %}
    <pre>{{ output }}</pre>
    {% endif %}
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def index():
    output = ""

    if request.method == 'POST':
        host = request.form.get('host', '')

        # VULNERABILIDAD INTENCIONAL
        # shell=True + entrada no sanitizada
        cmd = f"ping -c 1 {host}"

        try:
            result = subprocess.check_output(
                cmd,
                shell=True,
                stderr=subprocess.STDOUT,
                timeout=5,
                text=True
            )
            output = result
        except Exception as e:
            output = str(e)

    return render_template("index.html", output=output)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
